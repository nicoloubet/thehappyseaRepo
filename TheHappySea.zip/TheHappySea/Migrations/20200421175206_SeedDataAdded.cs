﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TheHappySea.Migrations
{
    public partial class SeedDataAdded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "CategoryId", "CategoryName", "Description" },
                values: new object[] { 1, "TANK TOPS", null });

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "CategoryId", "CategoryName", "Description" },
                values: new object[] { 2, "TEES", null });

            migrationBuilder.InsertData(
                table: "ApparelDbSet",
                columns: new[] { "ApparelId", "CategoryId", "ImageThumbnailUrl", "ImageUrl", "InStock", "LongDescription", "Name", "Price", "ShortDescription" },
                values: new object[] { 1, 1, "https://cdn.shopify.com/s/files/1/1429/9550/products/Dusty_Blue_Tuvalu_Beach_Tank2_1000x.png?v=1548095626", "https://cdn.shopify.com/s/files/1/1429/9550/products/Dusty_Blue_Tuvalu_Beach_Tank2_2000x.png?v=1548095626", true, "Slouchy, fun fitted tank Dusty Blue All of our apparel is manufactured in WRAP certified facilities.  65% Poly, 35% Viscose.  Screenprinted in-house in Fernandina Beach.", "DUSTY BLUE TUVALU BEACH TANK", 28.00m, "Slouchy, fun fitted tank!" });

            migrationBuilder.InsertData(
                table: "ApparelDbSet",
                columns: new[] { "ApparelId", "CategoryId", "ImageThumbnailUrl", "ImageUrl", "InStock", "LongDescription", "Name", "Price", "ShortDescription" },
                values: new object[] { 2, 1, "https://cdn.shopify.com/s/files/1/1429/9550/products/Monochromatic_Series_Online_1000x.jpg?v=1548344885", "https://cdn.shopify.com/s/files/1/1429/9550/products/Monochromatic_Series_Online_2000x.jpg?v=1548344885", true, "Slouchy, fun fitted tank Acid Wash Black All of our apparel is manufactured in WRAP certified facilities.  65% Poly, 35% Viscose.  Screenprinted in-house in Fernandina.", "ACID WASH BLACK MONOCHROME SHARK TANK", 28.00m, "Slouchy, fun fitted tank!" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "ApparelDbSet",
                keyColumn: "ApparelId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "ApparelDbSet",
                keyColumn: "ApparelId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 1);
        }
    }
}
