﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TheHappySea.Migrations
{
    public partial class IsSaleItems : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsSaleItems",
                table: "ApparelDbSet",
                nullable: false,
                defaultValue: false);

            migrationBuilder.UpdateData(
                table: "ApparelDbSet",
                keyColumn: "ApparelId",
                keyValue: 2,
                columns: new[] { "Name", "ShortDescription" },
                values: new object[] { "BLACK MONOCHROME SHARK TANK", "Acid wash slouchy, fun fitted tank!" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsSaleItems",
                table: "ApparelDbSet");

            migrationBuilder.UpdateData(
                table: "ApparelDbSet",
                keyColumn: "ApparelId",
                keyValue: 2,
                columns: new[] { "Name", "ShortDescription" },
                values: new object[] { "ACID WASH BLACK MONOCHROME SHARK TANK", "Slouchy, fun fitted tank!" });
        }
    }
}
