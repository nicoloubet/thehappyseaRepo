using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace TheHappySea
{
    public class Program
    {
        /* Host is being set up in Main and will configure a server and a request processing pipeline.
         Calling CreateHostBuilder which will set up an application with some defaults. 
         
         Using the Host.CreateDefaultBuilder(args). 
         One of the things that the ladder will do is config a webserver called Kestrel. 
         By default, the ASP.NET Core app is hosted on its own internal web server.
         */
        
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }
}
