﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TheHappySea.Models;

namespace TheHappySea.ViewModels
{
    //ViewModel: a class that will contian all the data for a view.
    //Controller will build up ViewModel and pass it to the view.
    public class ApparelListViewModel
    {
        public IEnumerable<Apparel> ApparelDbSet { get; set; }
        public string CurrentCategory { get; set; }
    }
}
