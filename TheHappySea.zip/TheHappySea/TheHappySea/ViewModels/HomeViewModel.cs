﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TheHappySea.Models;

namespace TheHappySea.ViewModels
{
    public class HomeViewModel
    {
        public IEnumerable<Apparel> SaleItems { get; set; }
    }
}
