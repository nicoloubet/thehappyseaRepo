using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using TheHappySea.Models;

namespace TheHappySea
{
    public class Startup
    {
        //By default appsettings.json gets read out and ends up in the instance of Iconfiguration below.
        //That instance then gets passed in the Startup() method below via constructor injection.
        //Now in this IConfiguration object, we'll have access to the properties, which are in appsettings.json
        public IConfiguration Configuration { get; }
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }


        // This method gets called by the runtime. Use this method to add services to the container.
        //Basically our entry point to add items into the services collection
        public void ConfigureServices(IServiceCollection services)
        {

            //On the services collection i call the extension method AddDbContext<>()
            //I pass the type of our DbContext which is <AppDbContext>
            //I then specify the options it needs to use SQL Server.
            //See the Startup() method above to see how we use Configuration.GetConnectionString() to get the connection string from the appsettings.json file.
            //Lastly pass in the connection String located in the appsettings.json file
            services.AddDbContext<AppDbContext>(options =>
                options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));

            //services.AddSingleton(); = Is basically going to create a single instance for the entire application and re - use that single instance.

            //services.AddTransient = Going to give you back a new instance everytime you ask for one.

            //services.AddScoped = "Middle ground." Per request a instance is created and that instance remains active, throughout the entire request. So as soon as that instance goes out of scope that instance will be discarded. Basically a singleton per request.
            services.AddScoped<IApparelRepository, ApparelRepository>();
            services.AddScoped<ICategoryRepository, CategoryRepository>();


            services.AddControllersWithViews();

        }

        
        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }
            app.UseHttpsRedirection();
            
            //used for serving static files i.e wwwroot
            app.UseStaticFiles();

            app.UseRouting();

            //Allows the use of Authentication within Identity
            app.UseAuthentication();
            
            //Allows the use of the [Authorization] attribute. ie on CONTROLLERS 
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
