﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace TheHappySea.Models
{
    //The repository class allows our code to use objects without knowing how they are persisted.
    //This class abstracts away the details of how persistence is happening. If really translated, we don't want to litter our code of the application with code that persists objects. All that code should be placed in a repository class, which can then be used from the application.
    //PieRepository will implement the Interface

    public class ApparelRepository : IApparelRepository
    {
        //Creating an _appDbContext local field 
        private readonly AppDbContext _appDbContext;

        //Gaining acces to AppDbContext class by injecting AppDbcontext into this constructor
        //Through this dependancy injection it makes it simple to access the AppDbContext class, which will be the intermediate between the code and the database
        //PieRepository will use the DbContext base class for persisting and reading data from the data base.
        public ApparelRepository (AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        
        //Implementing Interface. Remember with interfaces you must implement all properties. 
        public IEnumerable<Apparel> AllApparel 
        {
            get
            {
                //on _appDbContext which is actaully the AppDbContext class, i am going to ask for all the pies.
                //Pies is a DbSet, Under the hood it is going to send off a SQL query that will read out all the pies from the Pie.cs class.
                //.Include(c => c.Category) will read out the pies and for each of the pies it will read out the catagory. This will be done on the database level rather than in code.
                return _appDbContext.ApparelDbSet.Include(c => c.Category);
            }
        }

        public IEnumerable<Apparel> SaleItems
        {
            get
            {
                return _appDbContext.ApparelDbSet.Include(c => c.Category);
            }
        }
        public Apparel GetApparelById(int apparelId)
        {
            //.FirstOrDefault(a => a.ApparelId == apparelId); asking for the first piece of apparel where the ID is equal to the given ID.
            return _appDbContext.ApparelDbSet.FirstOrDefault(a => a.ApparelId == apparelId); 
        }

    }
}
