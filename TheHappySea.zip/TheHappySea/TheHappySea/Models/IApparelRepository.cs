﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TheHappySea.Models
{
    //This interface or the CONTRACT defines what our repository will be able to do initially.
    public interface IApparelRepository
    {
        IEnumerable<Apparel> AllApparel { get; }
        IEnumerable<Apparel> SaleItems { get; }

        //GetApparelById, which accepts the ID of the apparel we'll want to retrieve.
        Apparel GetApparelById(int apparelId);
    }
}
