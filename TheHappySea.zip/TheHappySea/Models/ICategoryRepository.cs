﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TheHappySea.Models
{
    public interface ICategoryRepository
    {
        //Pretty straight forward, will return all categories that we currently have.
        IEnumerable<Category> AllCategories { get; }
    }
}
