﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TheHappySea.Models
{
    //This class itself has no base class. It is just, a simple POCO(Plain old CLR objects) class
    //Simply represents Apparel instances through out the application
    public class Apparel
    {
        public int ApparelId { get; set; }
        public string Name { get; set; }
        public string ShortDescription { get; set; }
        public string LongDescription { get; set; }
        public decimal Price { get; set; }
        public string ImageUrl { get; set; }
        public string ImageThumbnailUrl { get; set; }
        public bool InStock { get; set; }
        public int CategoryId { get; set; }
        public Category Category { get; set; }
        public bool IsSaleItems { get; set; }

    }
}
