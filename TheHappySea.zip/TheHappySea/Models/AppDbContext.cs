﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace TheHappySea.Models
{
    //The DbContext represents a session with the database 
    //This class can be thought of as a bridge between the database and the applications code. 
    //It manages the entity objects during the runtime of the application. 
    //Populates objects with data from our database.
    //Responsible for reading out data from the database and also persisting data back to the database.
    public class AppDbContext : IdentityDbContext<IdentityUser>
    {
        //DbContext must have an instance of DbcontextOptions for it to execute. 
        //We acheive that by the constructor below.
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }

        
        
        //Essentially adding a DbSet<> property will be an indication to EF Core that there will be a corresponding table in the database. 
        //For example. Below is the <Apparel> table property. 
        //Through this property, we can access the data and the values in this table. 
        //DO NOT FORGET!!
        //1.) Add-Migration "Given name"
        //2.) Update-database
        public DbSet<Apparel> ApparelDbSet { get; set; }
        public DbSet<Category> Categories { get; set; }

        
        
        
        
        //OnModelCreating method is a reccomended technique used to seed data if there in none in current database.
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //seed(Add) categories
            modelBuilder.Entity<Category>().HasData(new Category { CategoryId = 1, CategoryName = "TANK TOPS" });
            modelBuilder.Entity<Category>().HasData(new Category { CategoryId = 2, CategoryName = "TEES" });
          


            //seed(Add) Apparel
             modelBuilder.Entity<Apparel>().HasData(new Apparel
            {
                ApparelId = 1,
                Name = "DUSTY BLUE TUVALU BEACH TANK",
                Price = 28.00M,
                ShortDescription = "Slouchy, fun fitted tank!",
                LongDescription =
                    "Slouchy, fun fitted tank Dusty Blue All of our apparel is manufactured in WRAP certified facilities.  65% Poly, 35% Viscose.  Screenprinted in-house in Fernandina Beach.",
                CategoryId = 1,
                ImageUrl = "https://cdn.shopify.com/s/files/1/1429/9550/products/Dusty_Blue_Tuvalu_Beach_Tank2_2000x.png?v=1548095626",
                InStock = true,
                ImageThumbnailUrl = "https://cdn.shopify.com/s/files/1/1429/9550/products/Dusty_Blue_Tuvalu_Beach_Tank2_1000x.png?v=1548095626",

            });

            modelBuilder.Entity<Apparel>().HasData(new Apparel
            {
                ApparelId = 2,
                Name = "BLACK MONOCHROME SHARK TANK",
                Price = 28.00M,
                ShortDescription ="Acid wash slouchy, fun fitted tank!",
                LongDescription =
                    "Slouchy, fun fitted tank Acid Wash Black All of our apparel is manufactured in WRAP certified facilities.  65% Poly, 35% Viscose.  Screenprinted in-house in Fernandina.",
                CategoryId = 1,
                ImageUrl = "https://cdn.shopify.com/s/files/1/1429/9550/products/Monochromatic_Series_Online_2000x.jpg?v=1548344885",
                InStock = true,
                ImageThumbnailUrl = "https://cdn.shopify.com/s/files/1/1429/9550/products/Monochromatic_Series_Online_1000x.jpg?v=1548344885",

            });

            
        }
    }
}
