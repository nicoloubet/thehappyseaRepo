﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace TheHappySea.Models
{
    //The repository class allows our code to use objects without knowing how they are persisted(SAVED).
    //This class abstracts away the details of how persistence is happening. If really translated, we don't want to litter our code of the application with code that persists objects. All that code should be placed in a repository class, which can then be used from the application.
   
    //ApparelRepository will implement the Interface. Meaning it has to implement all of the IApparelRepository interface members.
    public class ApparelRepository : IApparelRepository
    {
        //Creating an _appDbContext local field. 
        private readonly AppDbContext _appDbContext;

        //Gaining acces to AppDbContext class by injecting AppDbcontext into this constructor
        //Through this constructor injection it makes it simple to access the AppDbContext class, which will be the intermediate between the code and the database
        //ApparelRepository will use the DbContext base class for persisting and reading data from the data base.
        //_apparelDbcontext is a dependancy.  
        public ApparelRepository (AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        
        //Implementing Interface. Remember with interfaces you must implement all memembers. 
        public IEnumerable<Apparel> AllApparel 
        {
            get
            {
                //on _appDbContext which is actaully the AppDbContext class, i am going to ask for all the apparel.
                //ApparelDbSet is a DbSet, Under the hood it is going to send off a SQL query that will read out all the apparel from the Apparel.cs class.
                //.Include(c => c.Category) will read out the apparel and for each of the apparel it will read out the catagory. This will be done on the database level rather than in code.
                return _appDbContext.ApparelDbSet.Include(c => c.Category);
            }
        }

        public IEnumerable<Apparel> SaleItems
        {
            get
            {
                return _appDbContext.ApparelDbSet.Include(c => c.Category).Where(s => s.IsSaleItems);
            }
        }
        public Apparel GetApparelById(int apparelId)
        {
            //.FirstOrDefault(a => a.ApparelId == apparelId); asking for the first piece of apparel where the ID is equal to the given ID.
            return _appDbContext.ApparelDbSet.FirstOrDefault(a => a.ApparelId == apparelId); 
        }

    }
}
