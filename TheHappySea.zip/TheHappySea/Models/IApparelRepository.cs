﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TheHappySea.Models
{
    //This interface or the CONTRACT defines what our repository will be able to do initially. When a class implements a interface, it promises that it will have a certain set of functionality in this case in the form of properties.
    public interface IApparelRepository
    {
        //IEnumerable<T> Allows for the ability to iterate over the items in a collection. Basically keep asking for the next item until we get to the end.
        IEnumerable<Apparel> AllApparel { get; }
        IEnumerable<Apparel> SaleItems { get; }

        //GetApparelById, which accepts the ID of the apparel we'll want to retrieve.
        Apparel GetApparelById(int apparelId);
    }
}
