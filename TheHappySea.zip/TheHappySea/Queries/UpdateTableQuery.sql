USE[TheHappySea]
GO

UPDATE dbo.ApparelDbSet
SET ShortDescription ='Slouchy fit, with a side slit'
WHERE ApparelId = 1001;

GO