USE [TheHappySea]
GO

INSERT INTO [dbo].[ApparelDbSet]
           ([Name]
           ,[ShortDescription]
           ,[LongDescription]
           ,[Price]
           ,[ImageUrl]
           ,[ImageThumbnailUrl]
           ,[InStock]
           ,[CategoryId])
     
VALUES (
				'MOON SERIES SIDE SLIT TANK',
                'Slouchy, relaxed fit, with a side slit in the side.',
                'Slouchy, relaxed fit, with a side slit in the side. All of our apparel is manufactured in WRAP certified facilities.65 % Poly,35 % Viscose.Screenprinted in-house in Fernandina Beach,Florida.We donate to multiple ocean conservation nonprofits throughout the year such as Orca Conservancy, Ocean Alliance,and Sea to Shore.',
				 30.00,
                'https://cdn.shopify.com/s/files/1/1429/9550/products/Monochromatic_Series_Online5_2000x.jpg?v=1548344519',
                'https://cdn.shopify.com/s/files/1/1429/9550/products/Monochromatic_Series_Online5_1000x.jpg?v=1548344519',
				'true',
				1);
GO