﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TheHappySea.Models;

namespace TheHappySea.ViewModels
{
    //ViewModel: represents the data that you want to display on your view/page, whether it be used for static text or for input values(like textboxes and dropdown lists) that can be added to the database (or edited). It is something different than your domain model. It is a model for the view.
    //ViewModel: a class that will contian all the data for a view.
    //Controller will build up ViewModel and pass it to the view.
    public class ApparelListViewModel
    {
        public IEnumerable<Apparel> ApparelDbSet { get; set; }
        public string CurrentCategory { get; set; }
    }
}
