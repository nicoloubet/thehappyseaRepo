﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TheHappySea.Models;

namespace TheHappySea.ViewModels
//TODO: Only display sale items. Right now it is just pulling data from the ApparelDbSet table. Which is a table that contains all apparel.

{
    public class HomeViewModel
    {
        public IEnumerable<Apparel> SaleItems { get; set; }
    }
}
