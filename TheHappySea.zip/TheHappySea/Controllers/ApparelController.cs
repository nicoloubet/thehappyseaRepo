﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using TheHappySea.Models;
using TheHappySea.ViewModels;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TheHappySea.Controllers
{
    public class ApparelController : Controller
    {
        //These fields do not get initilized automatically. We will do that using the  ApparelController contsructor below.
        private readonly IApparelRepository _apparelRepository;
        private readonly ICategoryRepository _categoryRepository;

        //ApparelController Constructor:  that is being passed IApparelRepository and ICategoryRepository. These will be injected into our controller because we have registered them in the Startup.cs ConfigureServices() method.
        public ApparelController(IApparelRepository apparelRepository, ICategoryRepository categoryRepository)
        {
            _apparelRepository = apparelRepository;
            _categoryRepository = categoryRepository;
        }


        public ViewResult List(string category)
        {
            IEnumerable<Apparel> apparel;
            string currentCategory;

            if (string.IsNullOrEmpty(category))
            {
                apparel = _apparelRepository.AllApparel.OrderBy(a => a.ApparelId);
                currentCategory = "All apparel";
            }
            else
            {
                apparel = _apparelRepository.AllApparel.Where(a => a.Category.CategoryName == category)
                    .OrderBy(a => a.ApparelId);
                currentCategory = _categoryRepository.AllCategories.FirstOrDefault(c => c.CategoryName == category)?.CategoryName;
            }

            return View(new ApparelListViewModel
            {
                ApparelDbSet = apparel,
                CurrentCategory = currentCategory
            });
        }


        public IActionResult TankList(string category)
        {
            IEnumerable<Apparel> apparel;
            string currentCategory;

            if (string.IsNullOrEmpty(category))
            {
                apparel = _apparelRepository.AllApparel.Where(a => a.CategoryId == 1);
                currentCategory = "Tank Tops";
            }
            else
            {
                apparel = _apparelRepository.AllApparel.Where(a => a.Category.CategoryName == category)
                    .OrderBy(a => a.ApparelId);
                currentCategory = _categoryRepository.AllCategories.FirstOrDefault(c => c.CategoryName == category)?.CategoryName;
            }

            return View(new ApparelListViewModel
            {
                ApparelDbSet = apparel,
                CurrentCategory = currentCategory
            });
        }

        public IActionResult TeeList(string category)
        {
            IEnumerable<Apparel> apparel;
            string currentCategory;

            if (string.IsNullOrEmpty(category))
            {
                apparel = _apparelRepository.AllApparel.Where(a => a.CategoryId == 2);
                currentCategory = "TEES";
            }
            else
            {
                apparel = _apparelRepository.AllApparel.Where(a => a.Category.CategoryName == category)
                    .OrderBy(a => a.ApparelId);
                currentCategory = _categoryRepository.AllCategories.FirstOrDefault(c => c.CategoryName == category)?.CategoryName;
            }

            return View(new ApparelListViewModel
            {
                ApparelDbSet = apparel,
                CurrentCategory = currentCategory
            });
        }
    }
}
